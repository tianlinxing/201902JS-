// 获取元素
let $btn = $('.music_icon');

let isRunning = false;// 判断按钮是否在旋转
$btn.on('touchend',function(){
    // 用什么依据判断 是否在转
    if(isRunning){
        // 点击时 若按钮在旋转；则让他停止
        $(this).css({animationPlayState:'paused'});
        isRunning = false;
    }else{
        $(this).css({animationPlayState:'running'});
        isRunning = true;
    }
})