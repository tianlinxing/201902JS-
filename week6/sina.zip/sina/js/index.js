let $tab = $('.tab'),
    $tabBody = $('.tab_body');
$tab.on('click', function (e) {
    let $target = $(e.target);
    // 下边的代码执行必须保证点击的是 li元素
    // 我们使用标签名 作为判断的依据
    if (e.target.tagName.toUpperCase() !== 'LI') return;
    let n = $target.index()
    console.log(n);
    $target.addClass('current').siblings().removeClass('current');
    // $xxx.index() 是获取该元素在父盒子中的索引值
    $tabBody.addClass('hide').eq(n).removeClass('hide');
})

function swiperInit() {
    let swiper = new Swiper('.swiper-container', {
        autoplay: {

        },
        loop: true,
        pagination: {
            el: '.swiper-pagination',
            type: 'fraction',
            // currentClass:'current', 修改当前索引的元素类名
            // totalClass:'total' 修改总数的元素类名
        }
    })
}


// 获取banner数据
function getData() {
    $.ajax({
        url:"./data/banner.json",
        type:"get",// 老版是 type;  新版式 methods
        success:function(data){
            //请求成功之后的回调函数
            console.log(data);
            // 请求成功之后 把数据渲染到页面上
            renderBanner(data);
            
            // 初始化 swiper时需要保证 banner已经渲染完成
            swiperInit();
        },
        error:function(){
            // 请求失败之后的回调函数
        }
    })
}
getData();

// 把从后台获取到的数据 渲染到页面
function renderBanner(ary) {
    let str = '';
    ary = ary || [];// 容错机制
    ary.forEach(item => {
        let {text,src,href} = item;
        str += `<div class="swiper-slide">
                    <img src="${src}" alt="">
                </div>`
    });
    $('.swiper-wrapper').html(str);
    // $('.swiper-wrapper')[0].innerHTML = str;
}