document.getElementsByTagName('button')[0].onclick = function () {
    console.log(666)
}