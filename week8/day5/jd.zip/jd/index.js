// 全局过滤器
Vue.filter('money',function(val,n=2){
    return '￥'+(val/100).toFixed(n);
})
let vm = new Vue({
    el:'#app',
    data:{
        ary:[]
    },
    created() {
        // 一进页面 就获取数据
        this.getData();
    },
    methods: {
        getData(){
            axios.get('./data.json').then((data)=>{
                //data.data 是我们要使用的数据
                this.ary = data.data
            }).catch((err)=>{

            })
        },
        changeCount(item,e){
            // count 必须是正整数
            // item.count = (item.count+'').replace(/[^\d]*/g,'')
            // console.log(item.count,e.target)
            let str = (item.count+'').replace(/[^\d]*/g,'');
            str = str.replace(/^0/,'');
            item.count = str;
        },
        del(n){
            this.ary.splice(n,1);// 删除指定项
        },
        clear(){
            // 清空购物车
            this.ary = [];
        }
    },
})
// 1、从后台获取数据  渲染到页面上