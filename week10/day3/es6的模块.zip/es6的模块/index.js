// import qqq from './a.js' //从 a 文件中 引入 str 
// console.log(qqq);
import * as qqq from './a.js'
console.log(qqq)