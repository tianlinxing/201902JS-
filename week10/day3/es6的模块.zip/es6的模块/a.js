let str = '你好',
    n = 123;
    
// 导出一个对象    
// export default{
//     str,
//     n
// }
// 使用 export default导出
// 引入是 变量名 可以自定义
export var a = 12;
export let b = '123';
export const c = {};
export function d(){
    console.log('hello')
}